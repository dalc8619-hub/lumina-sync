
import { GoogleGenAI, Type } from "@google/genai";
import { MoodResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAILightingMood = async (userPrompt: string): Promise<MoodResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Suggest a professional lighting mood for smart LED strips based on this vibe: "${userPrompt}". 
                The lighting should be elegant and enhance the atmosphere.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            primaryColor: { type: Type.STRING, description: "HEX color for primary lights" },
            secondaryColor: { type: Type.STRING, description: "HEX color for secondary accents" },
            accentColor: { type: Type.STRING, description: "HEX color for tertiary highlights" },
            intensity: { type: Type.NUMBER, description: "Brightness from 0 to 100" },
            patternName: { type: Type.STRING, description: "Name of the lighting pattern (e.g., Pulsar, Wave, Static)" },
            vibeDescription: { type: Type.STRING, description: "Short description of why this mood fits" }
          },
          required: ["primaryColor", "secondaryColor", "accentColor", "intensity", "patternName", "vibeDescription"]
        }
      }
    });

    const result = JSON.parse(response.text);
    return result;
  } catch (error) {
    console.error("Error fetching AI lighting mood:", error);
    // Return a fallback mood if API fails
    return {
      primaryColor: "#4f46e5",
      secondaryColor: "#9333ea",
      accentColor: "#ec4899",
      intensity: 80,
      patternName: "Deep Aurora",
      vibeDescription: "A sophisticated blend of cool indigos and electric purples."
    };
  }
};
