
import React, { useState } from 'react';
import { getAILightingMood } from '../services/geminiService';
import { MoodResponse } from '../types';

const MoodGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [mood, setMood] = useState<MoodResponse | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    const result = await getAILightingMood(prompt);
    setMood(result);
    setLoading(false);
  };

  return (
    <section id="experiencia" className="py-24 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-950 rounded-[3rem] p-8 md:p-16 border border-slate-800 shadow-2xl overflow-hidden relative">
          
          {/* Decorative background element for the interactive feel */}
          <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
            <div 
              className="w-full h-full blur-[80px]"
              style={{
                background: mood 
                  ? `radial-gradient(circle, ${mood.primaryColor} 0%, ${mood.secondaryColor} 50%, transparent 100%)`
                  : 'radial-gradient(circle, #4f46e5 0%, transparent 100%)'
              }}
            ></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center relative z-10">
            <div>
              <h2 className="text-4xl md:text-5xl font-black font-outfit mb-6 leading-tight">
                Deja que la <span className="text-indigo-500">Inteligencia Artificial</span> diseñe tu vibra
              </h2>
              <p className="text-slate-400 text-lg mb-10">
                Escribe cómo te sientes o qué estás haciendo y LuminaSync creará la paleta de colores perfecta para ti.
              </p>

              <div className="space-y-4">
                <div className="relative">
                  <input 
                    type="text" 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Ej: Noche de cine cyberpunk, Sesión de estudio relajada..."
                    className="w-full px-6 py-5 bg-slate-900 border border-slate-800 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-white transition-all"
                  />
                  <button 
                    onClick={handleGenerate}
                    disabled={loading}
                    className="absolute right-3 top-3 bottom-3 px-6 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-500 transition-all disabled:opacity-50"
                  >
                    {loading ? 'Generando...' : 'Generar Escena'}
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {['Party hard', 'Noche romántica', 'Concentración total', 'Sunrise'].map((tag) => (
                    <button 
                      key={tag}
                      onClick={() => setPrompt(tag)}
                      className="text-xs px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-full transition-colors"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-inner">
              {mood ? (
                <div className="space-y-8 animate-in fade-in duration-500">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">Patrón sugerido</p>
                      <h4 className="text-2xl font-black font-outfit">{mood.patternName}</h4>
                    </div>
                    <div className="flex -space-x-2">
                      <div className="w-8 h-8 rounded-full border-2 border-slate-900" style={{ backgroundColor: mood.primaryColor }}></div>
                      <div className="w-8 h-8 rounded-full border-2 border-slate-900" style={{ backgroundColor: mood.secondaryColor }}></div>
                      <div className="w-8 h-8 rounded-full border-2 border-slate-900" style={{ backgroundColor: mood.accentColor }}></div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="aspect-video rounded-xl" style={{ backgroundColor: mood.primaryColor }}></div>
                    <div className="aspect-video rounded-xl" style={{ backgroundColor: mood.secondaryColor }}></div>
                    <div className="aspect-video rounded-xl" style={{ backgroundColor: mood.accentColor }}></div>
                  </div>

                  <p className="text-slate-400 italic text-sm">
                    "{mood.vibeDescription}"
                  </p>

                  <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-400">Intensidad: {mood.intensity}%</span>
                    <button className="text-indigo-400 text-sm font-bold hover:underline">Sincronizar ahora</button>
                  </div>
                </div>
              ) : (
                <div className="h-64 flex flex-col items-center justify-center text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-600">
                    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                    </svg>
                  </div>
                  <p className="text-slate-500 font-medium max-w-[200px]">Ingresa una idea para ver la magia de LuminaSync</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MoodGenerator;
