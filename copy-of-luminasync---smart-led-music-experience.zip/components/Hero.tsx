
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-0 -left-20 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-1/2 -right-20 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[150px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 border border-slate-700 mb-8 animate-bounce">
          <span className="flex h-2 w-2 rounded-full bg-indigo-500"></span>
          <span className="text-sm font-semibold text-indigo-400">Nuevo: Sincronización AI 2.0</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black font-outfit mb-8 tracking-tight leading-tight">
          La luz que baila al <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
            ritmo de tu vida
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-slate-400 max-w-3xl mx-auto mb-12 leading-relaxed">
          Transforma cualquier espacio en un escenario inmersivo. LuminaSync utiliza procesamiento de audio en tiempo real para crear atmósferas visuales que se adaptan a cada nota, cada película y cada emoción.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#comprar" className="w-full sm:w-auto px-10 py-5 bg-white text-slate-950 rounded-2xl font-bold text-lg hover:bg-slate-200 transition-all shadow-xl shadow-white/5">
            Comprar Kit Premium
          </a>
          <a href="#experiencia" className="w-full sm:w-auto px-10 py-5 bg-slate-900 text-white border border-slate-700 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all">
            Ver Demo Interactiva
          </a>
        </div>

        {/* Hero Visual */}
        <div className="mt-20 relative rounded-3xl overflow-hidden border border-slate-800 shadow-2xl">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10"></div>
          <img 
            src="https://picsum.photos/seed/lighting/1600/800" 
            alt="LuminaSync Environment" 
            className="w-full h-auto object-cover opacity-60 grayscale-[50%]"
          />
          <div className="absolute bottom-10 left-10 z-20 text-left">
            <p className="text-sm font-bold text-indigo-400 uppercase tracking-widest mb-2">Studio Edition</p>
            <h3 className="text-3xl font-bold font-outfit">Sinfonía Visual Infinita</h3>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
