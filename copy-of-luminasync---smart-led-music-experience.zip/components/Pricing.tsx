
import React from 'react';

const Pricing: React.FC = () => {
  return (
    <section id="comprar" className="py-24 bg-indigo-950/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-slate-900 rounded-[3rem] p-10 md:p-16 border border-indigo-500/30 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-6 bg-indigo-600 text-white font-bold text-sm rounded-bl-3xl">
            OFERTA DE LANZAMIENTO
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-black font-outfit mb-6">LuminaSync Pro Kit</h2>
              <ul className="space-y-4 mb-8">
                {[
                  "5 Metros de LED RGB+IC",
                  "Módulo de Audio con DSP",
                  "Control Remoto IR + App",
                  "Compatible con Alexa/Google",
                  "Garantía de 2 años"
                ].map(item => (
                  <li key={item} className="flex items-center gap-3 text-slate-300">
                    <svg className="w-5 h-5 text-indigo-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                    {item}
                  </li>
                ))}
              </ul>
              
              <div className="flex items-baseline gap-4 mb-8">
                <span className="text-5xl font-black font-outfit">49,99€</span>
                <span className="text-xl text-slate-500 line-through">79,99€</span>
              </div>
              
              <button className="w-full py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-xl transition-all shadow-xl shadow-indigo-600/20 transform hover:-translate-y-1">
                Añadir al Carrito
              </button>
              <p className="text-center text-slate-500 text-xs mt-4">
                Envío gratuito en 24/48h • Pago seguro SSL
              </p>
            </div>
            
            <div className="relative group">
              <div className="absolute inset-0 bg-indigo-500/20 rounded-3xl blur-2xl group-hover:bg-indigo-500/30 transition-all"></div>
              <img 
                src="https://picsum.photos/seed/product/600/600" 
                alt="Product Kit" 
                className="relative z-10 w-full h-auto rounded-3xl shadow-2xl border border-slate-700"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
