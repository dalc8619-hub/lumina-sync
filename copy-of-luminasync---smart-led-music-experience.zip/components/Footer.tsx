
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 pt-20 pb-10 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <span className="text-xl font-bold font-outfit">LuminaSync</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Redefiniendo el concepto de iluminación ambiental. Tecnología de vanguardia para hogares que vibran.
            </p>
            <div className="flex gap-4">
               {['twitter', 'instagram', 'youtube'].map(s => (
                 <a key={s} href="#" className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 hover:text-white transition-colors">
                   <span className="sr-only">{s}</span>
                   <div className="w-5 h-5 bg-current opacity-20 rounded-sm"></div>
                 </a>
               ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-bold mb-6 font-outfit">Producto</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Especificaciones</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Compatibilidad</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Guía de Instalación</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">App Download</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 font-outfit">Empresa</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Sobre Nosotros</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Soporte Técnico</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Privacidad</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Términos</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-slate-900 text-center text-slate-500 text-xs">
          <p>© 2024 LuminaSync Technologies Inc. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
