
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import MoodGenerator from './components/MoodGenerator';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 selection:bg-indigo-500 selection:text-white">
      <Navbar />
      
      <main>
        <Hero />
        <Features />
        <MoodGenerator />
        <Pricing />
        <Testimonials />
      </main>

      <Footer />
      
      {/* Scroll to Top Hidden Button Example */}
      <button 
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="fixed bottom-8 right-8 p-4 bg-slate-900/50 backdrop-blur border border-slate-800 rounded-full text-slate-400 hover:text-white hover:border-indigo-500 transition-all z-40"
        aria-label="Volver arriba"
      >
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
      </button>
    </div>
  );
};

export default App;
