// Added React import to resolve the 'Cannot find namespace React' error
import React from 'react';

export interface MoodResponse {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  intensity: number;
  patternName: string;
  vibeDescription: string;
}

export interface Feature {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface Testimonial {
  name: string;
  role: string;
  content: string;
  avatar: string;
}